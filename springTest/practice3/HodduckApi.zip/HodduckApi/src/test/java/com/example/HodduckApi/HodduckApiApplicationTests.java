package com.example.HodduckApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HodduckApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
