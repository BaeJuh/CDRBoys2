package com.example.practice2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practice2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
