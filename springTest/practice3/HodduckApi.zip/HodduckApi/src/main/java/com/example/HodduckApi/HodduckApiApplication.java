package com.example.HodduckApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HodduckApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HodduckApiApplication.class, args);
	}

}
